setwd("C:\\Users\\IT24101437\\Desktop\\IT24101437")

##Question 01
#Part 1
#Binomial Distribution
#Here, random variable X has binomial distribution with n = 50 and p = 0.85

1-pbinom(46,50,0.85,lower.tail = TRUE)

pbinom(46,50,0.85,lower.tail = FALSE)

##Question 02
#Part 1
#Number of calls received per hour

#Part 2
#Poisson distribution
#Here, random variable X has poisson distribution with lambda=12

ppois(15,12)

